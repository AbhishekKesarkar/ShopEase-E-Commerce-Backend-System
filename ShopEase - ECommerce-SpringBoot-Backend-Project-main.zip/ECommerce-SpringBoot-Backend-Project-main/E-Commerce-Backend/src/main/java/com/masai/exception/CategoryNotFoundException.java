package com.masai.exception;

public class CategoryNotFoundException extends RuntimeException{

	public CategoryNotFoundException() {
		// TODO Auto-generated constructor stub
	}
	
	
	public CategoryNotFoundException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}
	
}
